package com.lumi.avatar

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.graphics.RectF
import android.os.Bundle
import android.os.SystemClock
import android.text.InputType
import android.widget.EditText
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.*
import com.lumi.avatar.databinding.ActivityMainBinding
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : AppCompatActivity(), AvatarStreamClient.Listener {
    private lateinit var binding: ActivityMainBinding
    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private val detectorBusy = AtomicBoolean(false)
    private var streaming = false
    private var lastNetworkFrame = 0L
    private lateinit var streamClient: AvatarStreamClient

    private val faceDetector by lazy {
        val options = FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
            .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_ALL)
            .setMinFaceSize(0.15f)
            .enableTracking()
            .build()
        FaceDetection.getClient(options)
    }

    private val permissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (result[Manifest.permission.CAMERA] == true) startCamera()
        else Toast.makeText(this, "Camera permission is required", Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        streamClient = AvatarStreamClient(this)

        binding.startButton.setOnClickListener { toggleStreaming() }
        binding.settingsButton.setOnClickListener { showSettings() }
        binding.faceButton.setOnClickListener { toast("Face mode active") }
        binding.bodyButton.setOnClickListener { toast("Full-body tracking is the next module; current AI renderer is face/head.") }
        binding.voiceButton.setOnClickListener { toast("Voice/lip audio module is prepared for the next build.") }
        binding.recordButton.setOnClickListener { toast("Recording module is prepared for the next build.") }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else {
            permissions.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
        }
    }

    private fun toggleStreaming() {
        if (streaming) {
            streaming = false
            streamClient.disconnect()
            binding.startButton.text = "START"
            binding.syncBadge.text = "LOCAL PREVIEW"
            binding.liveStatus.text = "● OFFLINE"
            return
        }
        val prefs = getSharedPreferences("lumi", MODE_PRIVATE)
        val url = prefs.getString("serverUrl", "ws://192.168.1.100:8765/ws/avatar")!!
        streaming = true
        binding.startButton.text = "STOP"
        binding.liveStatus.text = "● CONNECTING"
        streamClient.connect(url)
    }

    private fun showSettings() {
        val prefs = getSharedPreferences("lumi", MODE_PRIVATE)
        val input = EditText(this).apply {
            setText(prefs.getString("serverUrl", "ws://192.168.1.100:8765/ws/avatar"))
            hint = "ws://PC-IP:8765/ws/avatar"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        }
        AlertDialog.Builder(this)
            .setTitle("AI GPU server")
            .setMessage("Enter the WebSocket address of the PC/GPU running the included backend.")
            .setView(input)
            .setPositiveButton("SAVE") { _, _ ->
                prefs.edit().putString("serverUrl", input.text.toString().trim()).apply()
            }
            .setNegativeButton("CANCEL", null)
            .show()
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()
            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(binding.previewView.surfaceProvider)
            }
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()

            analysis.setAnalyzer(cameraExecutor) { proxy ->
                try {
                    val bitmap = proxy.toRgbaBitmap()
                    processFace(bitmap)
                    val now = SystemClock.elapsedRealtime()
                    if (streaming && streamClient.isConnected() && now - lastNetworkFrame >= 83L) {
                        lastNetworkFrame = now
                        streamClient.sendFrame(bitmap.centerSquare(384).toJpeg(70))
                    }
                } catch (_: Throwable) {
                } finally {
                    proxy.close()
                }
            }

            provider.unbindAll()
            provider.bindToLifecycle(
                this,
                CameraSelector.DEFAULT_FRONT_CAMERA,
                preview,
                analysis
            )
            binding.cameraStatus.text = "● Camera On"
        }, ContextCompat.getMainExecutor(this))
    }

    private fun processFace(bitmap: android.graphics.Bitmap) {
        if (!detectorBusy.compareAndSet(false, true)) return
        val input = InputImage.fromBitmap(bitmap, 0)
        faceDetector.process(input)
            .addOnSuccessListener { faces ->
                val face = faces.firstOrNull()
                runOnUiThread {
                    if (face == null) {
                        binding.faceStatus.text = "○ Face"
                        binding.faceOverlay.setFaceBox(null)
                        return@runOnUiThread
                    }
                    binding.faceStatus.text = "● Face tracked"
                    val b = face.boundingBox
                    val n = RectF(
                        (b.left.toFloat() / bitmap.width).coerceIn(0f, 1f),
                        (b.top.toFloat() / bitmap.height).coerceIn(0f, 1f),
                        (b.right.toFloat() / bitmap.width).coerceIn(0f, 1f),
                        (b.bottom.toFloat() / bitmap.height).coerceIn(0f, 1f)
                    )
                    binding.faceOverlay.setFaceBox(n)
                    val blink = ((face.leftEyeOpenProbability ?: 1f) < .45f || (face.rightEyeOpenProbability ?: 1f) < .45f)
                    val smile = (face.smilingProbability ?: 0f) > .45f
                    binding.chipBlink.text = if (blink) "● Eye Blink" else "Eye Blink"
                    binding.chipSmile.text = if (smile) "● Expression" else "Expression"
                    binding.chipPose.text = "Head ${face.headEulerAngleY.toInt()}°"
                }
            }
            .addOnCompleteListener { detectorBusy.set(false) }
    }

    override fun onConnected() = runOnUiThread {
        binding.liveStatus.text = "● LIVE"
        binding.syncBadge.text = "AI SYNCED"
    }

    override fun onDisconnected(reason: String) = runOnUiThread {
        binding.liveStatus.text = "● OFFLINE"
        binding.syncBadge.text = "LOCAL PREVIEW"
        if (streaming) Toast.makeText(this, "AI server: $reason", Toast.LENGTH_SHORT).show()
    }

    override fun onAvatarFrame(jpeg: ByteArray, latencyMs: Long) = runOnUiThread {
        BitmapFactory.decodeByteArray(jpeg, 0, jpeg.size)?.let { binding.avatarView.setImageBitmap(it) }
        binding.latencyStatus.text = "Latency ${latencyMs} ms"
    }

    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        super.onDestroy()
        streamClient.disconnect()
        faceDetector.close()
        cameraExecutor.shutdown()
    }
}

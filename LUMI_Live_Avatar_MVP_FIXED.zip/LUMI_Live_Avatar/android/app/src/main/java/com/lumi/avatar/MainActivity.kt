package com.lumi.avatar

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.graphics.RectF
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceContour
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.lumi.avatar.databinding.ActivityMainBinding
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : AppCompatActivity(), AvatarStreamClient.Listener {
    private lateinit var binding: ActivityMainBinding
    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private val detectorBusy = AtomicBoolean(false)
    private var trackingEnabled = true
    private lateinit var streamClient: AvatarStreamClient

    private val faceDetector by lazy {
        val options = FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
            .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_ALL)
            .setContourMode(FaceDetectorOptions.CONTOUR_MODE_ALL)
            .setMinFaceSize(0.15f)
            .enableTracking()
            .build()
        FaceDetection.getClient(options)
    }

    private val permissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (result[Manifest.permission.CAMERA] == true) startCamera()
        else Toast.makeText(this, "Camera permission is required", Toast.LENGTH_LONG).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        streamClient = AvatarStreamClient(this)

        binding.startButton.text = "STOP"
        binding.liveStatus.text = "● LOCAL LIVE"
        binding.syncBadge.text = "FACE SYNC"

        binding.startButton.setOnClickListener { toggleTracking() }
        binding.settingsButton.setOnClickListener {
            toast("Local 1:1 face sync is active. GPU neural mode can be added as the next renderer.")
        }
        binding.faceButton.setOnClickListener { toast("Face + eyes + mouth sync active") }
        binding.bodyButton.setOnClickListener { toast("Full-body tracking is the next module") }
        binding.voiceButton.setOnClickListener { toast("Voice module is the next module") }
        binding.recordButton.setOnClickListener { toast("Recording module is the next module") }

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {
            startCamera()
        } else {
            permissions.launch(arrayOf(Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO))
        }
    }

    private fun toggleTracking() {
        trackingEnabled = !trackingEnabled
        if (trackingEnabled) {
            binding.startButton.text = "STOP"
            binding.liveStatus.text = "● LOCAL LIVE"
            binding.syncBadge.text = "FACE SYNC"
        } else {
            binding.startButton.text = "START"
            binding.liveStatus.text = "● PAUSED"
            binding.syncBadge.text = "PAUSED"
            binding.avatarView.resetTracking()
        }
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)
        providerFuture.addListener({
            val provider = providerFuture.get()
            val preview = Preview.Builder().build().also {
                it.setSurfaceProvider(binding.previewView.surfaceProvider)
            }
            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()

            analysis.setAnalyzer(cameraExecutor) { proxy ->
                try {
                    val bitmap = proxy.toRgbaBitmap()
                    processFace(bitmap)
                } catch (_: Throwable) {
                } finally {
                    proxy.close()
                }
            }

            provider.unbindAll()
            provider.bindToLifecycle(
                this,
                CameraSelector.DEFAULT_FRONT_CAMERA,
                preview,
                analysis
            )
            binding.cameraStatus.text = "● Camera On"
        }, ContextCompat.getMainExecutor(this))
    }

    private fun processFace(bitmap: android.graphics.Bitmap) {
        if (!detectorBusy.compareAndSet(false, true)) return
        val input = InputImage.fromBitmap(bitmap, 0)
        faceDetector.process(input)
            .addOnSuccessListener { faces ->
                val face = faces.firstOrNull()
                runOnUiThread {
                    if (face == null) {
                        binding.faceStatus.text = "○ Face"
                        binding.faceOverlay.setFaceBox(null)
                        if (trackingEnabled) binding.avatarView.resetTracking()
                        return@runOnUiThread
                    }
                    renderTrackedFace(face, bitmap.width, bitmap.height)
                }
            }
            .addOnCompleteListener { detectorBusy.set(false) }
    }

    private fun renderTrackedFace(face: Face, frameWidth: Int, frameHeight: Int) {
        binding.faceStatus.text = "● Face tracked"
        val b = face.boundingBox
        val n = RectF(
            (b.left.toFloat() / frameWidth).coerceIn(0f, 1f),
            (b.top.toFloat() / frameHeight).coerceIn(0f, 1f),
            (b.right.toFloat() / frameWidth).coerceIn(0f, 1f),
            (b.bottom.toFloat() / frameHeight).coerceIn(0f, 1f)
        )
        binding.faceOverlay.setFaceBox(n)

        val leftEye = face.leftEyeOpenProbability ?: 1f
        val rightEye = face.rightEyeOpenProbability ?: 1f
        val smile = face.smilingProbability ?: 0f
        val mouth = mouthOpenAmount(face)
        val blink = leftEye < .45f || rightEye < .45f

        binding.chipBlink.text = if (blink) "● Eye Blink" else "Eye Blink"
        binding.chipSmile.text = if (mouth > .16f) "● Mouth ${(mouth * 100).toInt()}%" else if (smile > .45f) "● Expression" else "Expression"
        binding.chipPose.text = "Head ${face.headEulerAngleY.toInt()}°"

        if (trackingEnabled) {
            binding.avatarView.updateTracking(
                headYaw = face.headEulerAngleY,
                headPitch = face.headEulerAngleX,
                headRoll = face.headEulerAngleZ,
                centerX = (b.exactCenterX() / frameWidth).coerceIn(0f, 1f),
                centerY = (b.exactCenterY() / frameHeight).coerceIn(0f, 1f),
                leftEye = leftEye,
                rightEye = rightEye,
                mouth = mouth,
                smileAmount = smile
            )
        }
    }

    private fun mouthOpenAmount(face: Face): Float {
        val upper = face.getContour(FaceContour.UPPER_LIP_BOTTOM)?.points.orEmpty()
        val lower = face.getContour(FaceContour.LOWER_LIP_TOP)?.points.orEmpty()
        if (upper.isEmpty() || lower.isEmpty()) return 0f

        val upperY = upper.map { it.y }.average().toFloat()
        val lowerY = lower.map { it.y }.average().toFloat()
        val faceHeight = face.boundingBox.height().coerceAtLeast(1).toFloat()
        val normalizedGap = ((lowerY - upperY) / faceHeight).coerceAtLeast(0f)
        return ((normalizedGap - .008f) / .075f).coerceIn(0f, 1f)
    }

    // Optional remote neural renderer support remains compatible with the local UI.
    override fun onConnected() = runOnUiThread {
        binding.liveStatus.text = "● GPU LIVE"
        binding.syncBadge.text = "AI SYNCED"
    }

    override fun onDisconnected(reason: String) = runOnUiThread {
        if (trackingEnabled) {
            binding.liveStatus.text = "● LOCAL LIVE"
            binding.syncBadge.text = "FACE SYNC"
        }
    }

    override fun onAvatarFrame(jpeg: ByteArray, latencyMs: Long) = runOnUiThread {
        BitmapFactory.decodeByteArray(jpeg, 0, jpeg.size)?.let { binding.avatarView.setAvatarBitmap(it) }
        binding.latencyStatus.text = "Latency ${latencyMs} ms"
    }

    private fun toast(text: String) = Toast.makeText(this, text, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        super.onDestroy()
        streamClient.disconnect()
        faceDetector.close()
        cameraExecutor.shutdown()
    }
}

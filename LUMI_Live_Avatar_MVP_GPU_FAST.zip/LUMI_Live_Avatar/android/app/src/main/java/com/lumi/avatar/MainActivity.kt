package com.lumi.avatar

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.RectF
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceContour
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.lumi.avatar.databinding.ActivityMainBinding
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

class MainActivity : AppCompatActivity(), AvatarStreamClient.Listener {
    private lateinit var binding: ActivityMainBinding

    private val cameraExecutor = Executors.newSingleThreadExecutor()
    private val renderExecutor = Executors.newSingleThreadExecutor()

    private val detectorBusy = AtomicBoolean(false)
    private var trackingEnabled = true
    private lateinit var streamClient: AvatarStreamClient

    private val reconnectHandler = Handler(Looper.getMainLooper())
    private var activityAlive = true
    private var lastRemoteSendAt = 0L

    companion object {
        private const val LIVE_AVATAR_URL =
            "wss://0m0i625vpru6xs-8000.proxy.runpod.net/ws/avatar"

        // ~14 fps input. GPU/server drops stale frames automatically.
        private const val REMOTE_FRAME_INTERVAL_MS = 70L
        private const val REMOTE_CROP_SIZE = 384
        private const val REMOTE_JPEG_QUALITY = 58
    }

    private val faceDetector by lazy {
        val options = FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_FAST)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
            .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_ALL)
            .setContourMode(FaceDetectorOptions.CONTOUR_MODE_ALL)
            .setMinFaceSize(0.15f)
            .enableTracking()
            .build()
        FaceDetection.getClient(options)
    }

    private val permissions = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (result[Manifest.permission.CAMERA] == true) startCamera()
        else Toast.makeText(
            this,
            "Camera permission is required",
            Toast.LENGTH_LONG
        ).show()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        streamClient = AvatarStreamClient(this)

        binding.startButton.text = "STOP"
        binding.liveStatus.text = "● CONNECTING"
        binding.syncBadge.text = "GPU FAST"
        connectGpuRenderer()

        binding.startButton.setOnClickListener { toggleTracking() }
        binding.settingsButton.setOnClickListener {
            toast("GPU FAST: latest-frame streaming active")
        }
        binding.faceButton.setOnClickListener {
            toast("Face + eyes + mouth sync active")
        }
        binding.bodyButton.setOnClickListener {
            toast("Full-body tracking is the next module")
        }
        binding.voiceButton.setOnClickListener {
            toast("Voice module is the next module")
        }
        binding.recordButton.setOnClickListener {
            toast("Recording module is the next module")
        }

        if (
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED
        ) {
            startCamera()
        } else {
            permissions.launch(
                arrayOf(
                    Manifest.permission.CAMERA,
                    Manifest.permission.RECORD_AUDIO
                )
            )
        }
    }

    private fun toggleTracking() {
        trackingEnabled = !trackingEnabled

        if (trackingEnabled) {
            binding.startButton.text = "STOP"
            if (streamClient.isConnected()) {
                binding.liveStatus.text = "● GPU LIVE"
                binding.syncBadge.text = "AI SYNCED"
            } else {
                binding.liveStatus.text = "● CONNECTING"
                binding.syncBadge.text = "GPU FAST"
                connectGpuRenderer()
            }
        } else {
            binding.startButton.text = "START"
            binding.liveStatus.text = "● PAUSED"
            binding.syncBadge.text = "PAUSED"
            binding.avatarView.resetTracking()
        }
    }

    private fun startCamera() {
        val providerFuture = ProcessCameraProvider.getInstance(this)

        providerFuture.addListener({
            val provider = providerFuture.get()

            val preview = Preview.Builder()
                .build()
                .also {
                    it.setSurfaceProvider(binding.previewView.surfaceProvider)
                }

            val analysis = ImageAnalysis.Builder()
                .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                .setOutputImageFormat(ImageAnalysis.OUTPUT_IMAGE_FORMAT_RGBA_8888)
                .build()

            analysis.setAnalyzer(cameraExecutor) { proxy ->
                try {
                    val bitmap = proxy.toRgbaBitmap()
                    sendRemoteFrame(bitmap)
                    processFace(bitmap)
                } catch (_: Throwable) {
                } finally {
                    proxy.close()
                }
            }

            provider.unbindAll()
            provider.bindToLifecycle(
                this,
                CameraSelector.DEFAULT_FRONT_CAMERA,
                preview,
                analysis
            )

            binding.cameraStatus.text = "● Camera On"
        }, ContextCompat.getMainExecutor(this))
    }

    private fun connectGpuRenderer() {
        if (!activityAlive) return

        binding.liveStatus.text = "● CONNECTING"
        binding.syncBadge.text = "GPU FAST"
        streamClient.connect(LIVE_AVATAR_URL)
    }

    private fun sendRemoteFrame(bitmap: Bitmap) {
        if (!trackingEnabled || !streamClient.isConnected()) return

        val now = SystemClock.elapsedRealtime()
        if (now - lastRemoteSendAt < REMOTE_FRAME_INTERVAL_MS) return
        lastRemoteSendAt = now

        try {
            val jpeg = bitmap
                .centerSquare(REMOTE_CROP_SIZE)
                .toJpeg(REMOTE_JPEG_QUALITY)

            streamClient.sendFrame(jpeg)
        } catch (_: Throwable) {
        }
    }

    private fun processFace(bitmap: Bitmap) {
        if (!detectorBusy.compareAndSet(false, true)) return

        val input = InputImage.fromBitmap(bitmap, 0)

        faceDetector.process(input)
            .addOnSuccessListener { faces ->
                val face = faces.firstOrNull()

                runOnUiThread {
                    if (face == null) {
                        binding.faceStatus.text = "○ Face"
                        binding.faceOverlay.setFaceBox(null)

                        if (trackingEnabled) {
                            binding.avatarView.resetTracking()
                        }

                        return@runOnUiThread
                    }

                    renderTrackedFace(
                        face,
                        bitmap.width,
                        bitmap.height
                    )
                }
            }
            .addOnCompleteListener {
                detectorBusy.set(false)
            }
    }

    private fun renderTrackedFace(
        face: Face,
        frameWidth: Int,
        frameHeight: Int
    ) {
        binding.faceStatus.text = "● Face tracked"

        val b = face.boundingBox

        val normalized = RectF(
            (b.left.toFloat() / frameWidth).coerceIn(0f, 1f),
            (b.top.toFloat() / frameHeight).coerceIn(0f, 1f),
            (b.right.toFloat() / frameWidth).coerceIn(0f, 1f),
            (b.bottom.toFloat() / frameHeight).coerceIn(0f, 1f)
        )

        binding.faceOverlay.setFaceBox(normalized)

        val leftEye = face.leftEyeOpenProbability ?: 1f
        val rightEye = face.rightEyeOpenProbability ?: 1f
        val smile = face.smilingProbability ?: 0f
        val mouth = mouthOpenAmount(face)

        val blink = leftEye < .45f || rightEye < .45f

        binding.chipBlink.text =
            if (blink) "● Eye Blink" else "Eye Blink"

        binding.chipSmile.text =
            if (mouth > .16f) {
                "● Mouth ${(mouth * 100).toInt()}%"
            } else if (smile > .45f) {
                "● Expression"
            } else {
                "Expression"
            }

        binding.chipPose.text =
            "Head ${face.headEulerAngleY.toInt()}°"

        if (trackingEnabled) {
            binding.avatarView.updateTracking(
                headYaw = face.headEulerAngleY,
                headPitch = face.headEulerAngleX,
                headRoll = face.headEulerAngleZ,
                centerX = (b.exactCenterX() / frameWidth)
                    .coerceIn(0f, 1f),
                centerY = (b.exactCenterY() / frameHeight)
                    .coerceIn(0f, 1f),
                leftEye = leftEye,
                rightEye = rightEye,
                mouth = mouth,
                smileAmount = smile
            )
        }
    }

    private fun mouthOpenAmount(face: Face): Float {
        val upper =
            face.getContour(FaceContour.UPPER_LIP_BOTTOM)
                ?.points
                .orEmpty()

        val lower =
            face.getContour(FaceContour.LOWER_LIP_TOP)
                ?.points
                .orEmpty()

        if (upper.isEmpty() || lower.isEmpty()) return 0f

        val upperY =
            upper.map { it.y }.average().toFloat()

        val lowerY =
            lower.map { it.y }.average().toFloat()

        val faceHeight =
            face.boundingBox.height()
                .coerceAtLeast(1)
                .toFloat()

        val normalizedGap =
            ((lowerY - upperY) / faceHeight)
                .coerceAtLeast(0f)

        return ((normalizedGap - .008f) / .075f)
            .coerceIn(0f, 1f)
    }

    override fun onConnected() = runOnUiThread {
        binding.liveStatus.text = "● GPU LIVE"
        binding.syncBadge.text = "AI SYNCED"
    }

    override fun onDisconnected(reason: String) = runOnUiThread {
        if (trackingEnabled && activityAlive) {
            binding.liveStatus.text = "● RECONNECTING"
            binding.syncBadge.text = "GPU RETRY"

            reconnectHandler.removeCallbacksAndMessages(null)
            reconnectHandler.postDelayed(
                { connectGpuRenderer() },
                1500L
            )
        }
    }

    override fun onAvatarFrame(
        jpeg: ByteArray,
        latencyMs: Long
    ) {
        // JPEG decode is kept off the UI thread.
        renderExecutor.execute {
            val bitmap =
                BitmapFactory.decodeByteArray(
                    jpeg,
                    0,
                    jpeg.size
                )

            if (bitmap != null && activityAlive) {
                runOnUiThread {
                    binding.avatarView.setAvatarBitmap(bitmap)

                    binding.latencyStatus.text =
                        if (latencyMs > 0L) {
                            "Latency ${latencyMs} ms"
                        } else {
                            "GPU LIVE"
                        }
                }
            }
        }
    }

    private fun toast(text: String) =
        Toast.makeText(
            this,
            text,
            Toast.LENGTH_SHORT
        ).show()

    override fun onDestroy() {
        activityAlive = false
        reconnectHandler.removeCallbacksAndMessages(null)

        streamClient.disconnect()
        faceDetector.close()

        cameraExecutor.shutdown()
        renderExecutor.shutdown()

        super.onDestroy()
    }
}

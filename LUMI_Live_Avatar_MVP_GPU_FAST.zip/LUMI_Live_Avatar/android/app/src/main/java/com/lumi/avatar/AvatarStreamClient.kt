package com.lumi.avatar

import android.os.SystemClock
import okhttp3.*
import okio.ByteString
import okio.ByteString.Companion.toByteString
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.TimeUnit

class AvatarStreamClient(
    private val listener: Listener
) {
    interface Listener {
        fun onConnected()
        fun onDisconnected(reason: String)
        fun onAvatarFrame(jpeg: ByteArray, latencyMs: Long)
    }

    private val client = OkHttpClient.Builder()
        .pingInterval(10, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()

    private var socket: WebSocket? = null
    @Volatile private var connected = false

    fun connect(url: String) {
        disconnect()
        val request = Request.Builder().url(url).build()

        socket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                connected = true
                listener.onConnected()
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                val raw = bytes.toByteArray()
                if (raw.size < 2) return

                // Old server compatibility: raw JPEG begins with FF D8.
                if ((raw[0].toInt() and 0xFF) == 0xFF &&
                    (raw[1].toInt() and 0xFF) == 0xD8
                ) {
                    listener.onAvatarFrame(raw, 0L)
                    return
                }

                if (raw.size <= 10) return

                val sentAt = ByteBuffer.wrap(raw, 0, 8)
                    .order(ByteOrder.BIG_ENDIAN)
                    .long

                val jpeg = raw.copyOfRange(8, raw.size)
                val latency = (SystemClock.elapsedRealtime() - sentAt).coerceAtLeast(0L)
                listener.onAvatarFrame(jpeg, latency)
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                connected = false
                listener.onDisconnected(t.message ?: "Connection failed")
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                connected = false
                listener.onDisconnected(reason)
            }
        })
    }

    fun sendFrame(jpeg: ByteArray): Boolean {
        val s = socket ?: return false
        if (!connected) return false

        // If network output starts backing up, skip the frame instead of creating lag.
        if (s.queueSize() > 350_000) return false

        val now = SystemClock.elapsedRealtime()
        val packet = ByteBuffer.allocate(8 + jpeg.size)
            .order(ByteOrder.BIG_ENDIAN)
            .putLong(now)
            .put(jpeg)
            .array()

        return s.send(packet.toByteString())
    }

    fun disconnect() {
        connected = false
        socket?.close(1000, "stop")
        socket = null
    }

    fun isConnected(): Boolean = connected
}

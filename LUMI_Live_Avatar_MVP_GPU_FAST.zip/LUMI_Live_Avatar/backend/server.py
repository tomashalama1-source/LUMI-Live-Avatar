"""
LUMI GPU FAST bridge for FasterLivePortrait.

Optimizations:
- realtime=True with automatic upstream duplicate-kwarg patch
- latest-frame queue (drops stale camera frames instead of building latency)
- 384px input
- compressed 256px neural output
- timestamp echo for accurate round-trip latency
"""
from __future__ import annotations

import asyncio
import os
import struct
import sys
from pathlib import Path

import cv2
import numpy as np
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
import uvicorn

HERE = Path(__file__).resolve().parent
FLP_ROOT = Path(os.getenv("FLP_ROOT", HERE.parent / "FasterLivePortrait")).resolve()
SOURCE_IMAGE = Path(os.getenv("LUMI_SOURCE_IMAGE", HERE / "assets" / "ai_model.png")).resolve()
CFG = os.getenv("LUMI_FLP_CONFIG", "configs/trt_mp_infer.yaml")

INPUT_SIZE = int(os.getenv("LUMI_INPUT_SIZE", "384"))
OUTPUT_SIZE = int(os.getenv("LUMI_OUTPUT_SIZE", "256"))
OUTPUT_JPEG_QUALITY = int(os.getenv("LUMI_OUTPUT_JPEG_QUALITY", "68"))

if not FLP_ROOT.exists():
    raise RuntimeError(f"FasterLivePortrait not found at {FLP_ROOT}. Clone it or set FLP_ROOT.")

# FasterLivePortrait currently reads `realtime` with kwargs.get() and later also
# forwards **kwargs into _run(), which can duplicate the same argument.
# Patch both run paths once so realtime=True is safe.
pipeline_file = FLP_ROOT / "src" / "pipelines" / "faster_live_portrait_pipeline.py"
if pipeline_file.exists():
    source = pipeline_file.read_text(encoding="utf-8")
    fixed = source.replace(
        'realtime = kwargs.get("realtime", False)',
        'realtime = kwargs.pop("realtime", False)',
    )
    if fixed != source:
        pipeline_file.write_text(fixed, encoding="utf-8")

os.chdir(FLP_ROOT)
sys.path.insert(0, str(FLP_ROOT))

from omegaconf import OmegaConf  # noqa: E402
from src.pipelines.faster_live_portrait_pipeline import FasterLivePortraitPipeline  # noqa: E402

cfg_path = FLP_ROOT / CFG
if not cfg_path.exists():
    cfg_path = FLP_ROOT / "configs" / "trt_infer.yaml"

infer_cfg = OmegaConf.load(str(cfg_path))
infer_cfg.infer_params.flag_pasteback = False
infer_cfg.infer_params.animation_region = "all"
infer_cfg.infer_params.flag_relative_motion = True
infer_cfg.infer_params.flag_stitching = True
infer_cfg.infer_params.flag_crop_driving_video = True

pipe = FasterLivePortraitPipeline(cfg=infer_cfg, is_animal=False)
if not pipe.prepare_source(str(SOURCE_IMAGE), realtime=True):
    raise RuntimeError(f"No face detected in AI source image: {SOURCE_IMAGE}")

app = FastAPI(title="LUMI GPU FAST")
model_lock = asyncio.Lock()


def decode_packet(data: bytes) -> tuple[int | None, bytes]:
    # New client: 8-byte big-endian timestamp followed by JPEG.
    if len(data) >= 10 and not (data[0] == 0xFF and data[1] == 0xD8):
        return struct.unpack(">Q", data[:8])[0], data[8:]
    # Backward compatibility with the older APK.
    return None, data


def encode_packet(sent_ms: int | None, jpeg: bytes) -> bytes:
    if sent_ms is None:
        return jpeg
    return struct.pack(">Q", sent_ms) + jpeg


def center_square_resize(frame: np.ndarray, size: int) -> np.ndarray:
    h, w = frame.shape[:2]
    side = min(h, w)
    x = (w - side) // 2
    y = (h - side) // 2
    crop = frame[y:y + side, x:x + side]
    interpolation = cv2.INTER_AREA if side >= size else cv2.INTER_LINEAR
    return cv2.resize(crop, (size, size), interpolation=interpolation)


@app.get("/health")
def health():
    return {
        "ok": True,
        "engine": "FasterLivePortrait",
        "mode": "gpu-fast-latest-frame",
        "input_size": INPUT_SIZE,
        "output_size": OUTPUT_SIZE,
        "jpeg_quality": OUTPUT_JPEG_QUALITY,
    }


@app.websocket("/ws/avatar")
async def avatar_socket(ws: WebSocket):
    await ws.accept()

    # Receiver runs independently of GPU inference. Queue size 1 means old
    # frames are discarded and the GPU always works on the newest face pose.
    latest: asyncio.Queue[bytes | None] = asyncio.Queue(maxsize=1)

    async def receiver():
        try:
            while True:
                packet = await ws.receive_bytes()
                if latest.full():
                    try:
                        latest.get_nowait()
                    except asyncio.QueueEmpty:
                        pass
                latest.put_nowait(packet)
        except (WebSocketDisconnect, RuntimeError):
            pass
        finally:
            if latest.full():
                try:
                    latest.get_nowait()
                except asyncio.QueueEmpty:
                    pass
            try:
                latest.put_nowait(None)
            except asyncio.QueueFull:
                pass

    receiver_task = asyncio.create_task(receiver())
    first = True

    try:
        while True:
            packet = await latest.get()
            if packet is None:
                break

            sent_ms, jpeg = decode_packet(packet)
            frame = cv2.imdecode(np.frombuffer(jpeg, np.uint8), cv2.IMREAD_COLOR)
            if frame is None:
                continue

            frame = center_square_resize(frame, INPUT_SIZE)

            async with model_lock:
                _, out_crop, _, _ = await asyncio.to_thread(
                    pipe.run,
                    frame,
                    pipe.src_imgs[0],
                    pipe.src_infos[0],
                    realtime=True,
                    first_frame=first,
                )
                first = False

            if out_crop is None:
                continue

            bgr = cv2.cvtColor(out_crop, cv2.COLOR_RGB2BGR)
            if OUTPUT_SIZE > 0 and (bgr.shape[0] != OUTPUT_SIZE or bgr.shape[1] != OUTPUT_SIZE):
                bgr = cv2.resize(bgr, (OUTPUT_SIZE, OUTPUT_SIZE), interpolation=cv2.INTER_AREA)

            ok, encoded = cv2.imencode(
                ".jpg",
                bgr,
                [cv2.IMWRITE_JPEG_QUALITY, OUTPUT_JPEG_QUALITY],
            )
            if not ok:
                continue

            await ws.send_bytes(encode_packet(sent_ms, encoded.tobytes()))
    except (WebSocketDisconnect, RuntimeError):
        pass
    finally:
        receiver_task.cancel()
        try:
            await receiver_task
        except BaseException:
            pass
        pipe.R_d_0 = None
        pipe.x_d_0_info = None
        pipe.src_lmk_pre = None


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=int(os.getenv("PORT", "8765")))

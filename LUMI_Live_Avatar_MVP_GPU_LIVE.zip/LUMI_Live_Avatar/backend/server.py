"""
LUMI real-time bridge for FasterLivePortrait.

The Android app sends a cropped JPEG from the front camera over WebSocket.
This bridge drives the fixed AI model image with each incoming frame and
returns the rendered portrait as JPEG.

Prerequisite: a working FasterLivePortrait installation with checkpoints.
"""
from __future__ import annotations

import asyncio
import os
import sys
import time
from pathlib import Path

import cv2
import numpy as np
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
import uvicorn

HERE = Path(__file__).resolve().parent
FLP_ROOT = Path(os.getenv("FLP_ROOT", HERE.parent / "FasterLivePortrait")).resolve()
SOURCE_IMAGE = Path(os.getenv("LUMI_SOURCE_IMAGE", HERE / "assets" / "ai_model.png")).resolve()
CFG = os.getenv("LUMI_FLP_CONFIG", "configs/trt_mp_infer.yaml")

if not FLP_ROOT.exists():
    raise RuntimeError(
        f"FasterLivePortrait not found at {FLP_ROOT}. Clone it or set FLP_ROOT."
    )

os.chdir(FLP_ROOT)
sys.path.insert(0, str(FLP_ROOT))

from omegaconf import OmegaConf  # noqa: E402
from src.pipelines.faster_live_portrait_pipeline import FasterLivePortraitPipeline  # noqa: E402

cfg_path = FLP_ROOT / CFG
if not cfg_path.exists():
    cfg_path = FLP_ROOT / "configs" / "trt_infer.yaml"

infer_cfg = OmegaConf.load(str(cfg_path))
# Crop output is ideal for the split-screen mobile UI and is faster than paste-back.
infer_cfg.infer_params.flag_pasteback = False
infer_cfg.infer_params.animation_region = "all"
infer_cfg.infer_params.flag_relative_motion = True
infer_cfg.infer_params.flag_stitching = True
infer_cfg.infer_params.flag_crop_driving_video = True

pipe = FasterLivePortraitPipeline(cfg=infer_cfg, is_animal=False)
if not pipe.prepare_source(str(SOURCE_IMAGE), realtime=True):
    raise RuntimeError(f"No face detected in AI source image: {SOURCE_IMAGE}")

app = FastAPI(title="LUMI Live Avatar Bridge")
model_lock = asyncio.Lock()

@app.get("/health")
def health():
    return {
        "ok": True,
        "engine": "FasterLivePortrait",
        "source": SOURCE_IMAGE.name,
        "config": str(cfg_path),
    }

@app.websocket("/ws/avatar")
async def avatar_socket(ws: WebSocket):
    await ws.accept()
    first = True
    try:
        while True:
            data = await ws.receive_bytes()
            frame = cv2.imdecode(np.frombuffer(data, np.uint8), cv2.IMREAD_COLOR)
            if frame is None:
                continue

            started = time.perf_counter()
            async with model_lock:
                _, out_crop, _, _ = await asyncio.to_thread(
                    pipe.run,
                    frame,
                    pipe.src_imgs[0],
                    pipe.src_infos[0],
                    realtime=True,
                    first_frame=first,
                )
                first = False

            if out_crop is None:
                continue
            # Pipeline crop is RGB; JPEG encoder expects BGR.
            bgr = cv2.cvtColor(out_crop, cv2.COLOR_RGB2BGR)
            ok, encoded = cv2.imencode(".jpg", bgr, [cv2.IMWRITE_JPEG_QUALITY, 82])
            if not ok:
                continue
            await ws.send_bytes(encoded.tobytes())
            print(f"frame {(time.perf_counter() - started) * 1000:.1f} ms", end="\r")
    except WebSocketDisconnect:
        pass
    finally:
        # Reset driver reference for the next session so neutral frame calibration starts fresh.
        pipe.R_d_0 = None
        pipe.x_d_0_info = None
        pipe.src_lmk_pre = None

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=int(os.getenv("PORT", "8765")))

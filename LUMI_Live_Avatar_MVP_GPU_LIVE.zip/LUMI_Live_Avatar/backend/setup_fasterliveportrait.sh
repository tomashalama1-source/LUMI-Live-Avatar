#!/usr/bin/env bash
set -e
ROOT="${1:-$(pwd)/FasterLivePortrait}"
if [ ! -d "$ROOT/.git" ]; then
  git clone https://github.com/warmshao/FasterLivePortrait "$ROOT"
fi
cd "$ROOT"
python -m pip install -r requirements.txt
python -m pip install "huggingface_hub[cli]"
huggingface-cli download warmshao/FasterLivePortrait --local-dir ./checkpoints
cat <<MSG
FasterLivePortrait code + checkpoints are present.
For real-time speed, follow its TensorRT setup and convert the ONNX models.
Then run the LUMI backend with:
  FLP_ROOT="$ROOT" python ../backend/server.py
MSG

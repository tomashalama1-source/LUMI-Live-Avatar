package com.lumi.avatar

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View

class FaceOverlayView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null
) : View(context, attrs) {
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 4f
        color = 0xFF43F0A3.toInt()
    }
    private var box: RectF? = null

    fun setFaceBox(normalized: RectF?) {
        box = normalized
        postInvalidateOnAnimation()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        box?.let {
            val r = RectF(it.left * width, it.top * height, it.right * width, it.bottom * height)
            canvas.drawRoundRect(r, 28f, 28f, paint)
        }
    }
}

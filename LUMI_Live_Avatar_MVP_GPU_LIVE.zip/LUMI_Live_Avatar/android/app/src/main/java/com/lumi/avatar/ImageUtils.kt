package com.lumi.avatar

import android.graphics.Bitmap
import android.graphics.Matrix
import androidx.camera.core.ImageProxy
import java.io.ByteArrayOutputStream

fun ImageProxy.toRgbaBitmap(): Bitmap {
    val plane = planes[0]
    val buffer = plane.buffer
    buffer.rewind()
    val pixelStride = plane.pixelStride
    val rowStride = plane.rowStride
    val rowPadding = rowStride - pixelStride * width
    val padded = Bitmap.createBitmap(width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888)
    padded.copyPixelsFromBuffer(buffer)
    var bitmap = Bitmap.createBitmap(padded, 0, 0, width, height)
    if (imageInfo.rotationDegrees != 0) {
        val m = Matrix().apply { postRotate(imageInfo.rotationDegrees.toFloat()) }
        bitmap = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, m, true)
    }
    return bitmap
}

fun Bitmap.centerSquare(size: Int): Bitmap {
    val side = minOf(width, height)
    val x = (width - side) / 2
    val y = (height - side) / 2
    val crop = Bitmap.createBitmap(this, x, y, side, side)
    return Bitmap.createScaledBitmap(crop, size, size, true)
}

fun Bitmap.toJpeg(quality: Int = 72): ByteArray {
    val out = ByteArrayOutputStream()
    compress(Bitmap.CompressFormat.JPEG, quality, out)
    return out.toByteArray()
}

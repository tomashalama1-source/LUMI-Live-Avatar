package com.lumi.avatar

import android.os.SystemClock
import okhttp3.*
import okio.ByteString
import okio.ByteString.Companion.toByteString
import java.util.concurrent.TimeUnit

class AvatarStreamClient(
    private val listener: Listener
) {
    interface Listener {
        fun onConnected()
        fun onDisconnected(reason: String)
        fun onAvatarFrame(jpeg: ByteArray, latencyMs: Long)
    }

    private val client = OkHttpClient.Builder()
        .pingInterval(10, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()
    private var socket: WebSocket? = null
    @Volatile private var connected = false
    @Volatile private var lastSentAt = 0L

    fun connect(url: String) {
        disconnect()
        val request = Request.Builder().url(url).build()
        socket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                connected = true
                listener.onConnected()
            }
            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                val now = SystemClock.elapsedRealtime()
                listener.onAvatarFrame(bytes.toByteArray(), (now - lastSentAt).coerceAtLeast(0L))
            }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                connected = false
                listener.onDisconnected(t.message ?: "Connection failed")
            }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                connected = false
                listener.onDisconnected(reason)
            }
        })
    }

    fun sendFrame(jpeg: ByteArray): Boolean {
        val s = socket ?: return false
        if (!connected || s.queueSize() > 1_500_000) return false
        lastSentAt = SystemClock.elapsedRealtime()
        return s.send(jpeg.toByteString())
    }

    fun disconnect() {
        connected = false
        socket?.close(1000, "stop")
        socket = null
    }

    fun isConnected(): Boolean = connected
}

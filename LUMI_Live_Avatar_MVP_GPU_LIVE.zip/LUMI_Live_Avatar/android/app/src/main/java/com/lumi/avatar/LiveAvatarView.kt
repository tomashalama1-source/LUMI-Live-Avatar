package com.lumi.avatar

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.util.AttributeSet
import android.view.View
import kotlin.math.abs
import kotlin.math.max

/**
 * Lightweight local 2D avatar puppeteer.
 * It keeps the supplied portrait local on the device and maps face tracking
 * values from ML Kit to head motion, eye blinks and mouth opening.
 *
 * This is intentionally a fast on-device preview renderer. A remote neural
 * renderer can still replace frames later without changing the camera/tracking
 * pipeline.
 */
class LiveAvatarView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
    defStyleAttr: Int = 0
) : View(context, attrs, defStyleAttr) {

    private val portrait: Bitmap = BitmapFactory.decodeResource(resources, R.drawable.ai_model)
    private var remoteFrame: Bitmap? = null

    private val bitmapPaint = Paint(Paint.ANTI_ALIAS_FLAG or Paint.FILTER_BITMAP_FLAG)
    private val skinPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFFE7B39F.toInt() }
    private val eyelidPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF5B3935.toInt()
        strokeWidth = resources.displayMetrics.density * 1.6f
        style = Paint.Style.STROKE
    }
    private val mouthPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF46151D.toInt() }
    private val lipPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF9B5664.toInt()
        strokeWidth = resources.displayMetrics.density * 1.4f
        style = Paint.Style.STROKE
    }

    private var yaw = 0f
    private var pitch = 0f
    private var roll = 0f
    private var faceX = .5f
    private var faceY = .5f
    private var leftEyeOpen = 1f
    private var rightEyeOpen = 1f
    private var mouthOpen = 0f
    private var smile = 0f

    fun updateTracking(
        headYaw: Float,
        headPitch: Float,
        headRoll: Float,
        centerX: Float,
        centerY: Float,
        leftEye: Float,
        rightEye: Float,
        mouth: Float,
        smileAmount: Float
    ) {
        // A little smoothing removes face-detector jitter while keeping motion responsive.
        yaw = smooth(yaw, headYaw.coerceIn(-45f, 45f), .38f)
        pitch = smooth(pitch, headPitch.coerceIn(-35f, 35f), .38f)
        roll = smooth(roll, headRoll.coerceIn(-35f, 35f), .42f)
        faceX = smooth(faceX, centerX.coerceIn(0f, 1f), .26f)
        faceY = smooth(faceY, centerY.coerceIn(0f, 1f), .26f)
        leftEyeOpen = smooth(leftEyeOpen, leftEye.coerceIn(0f, 1f), .55f)
        rightEyeOpen = smooth(rightEyeOpen, rightEye.coerceIn(0f, 1f), .55f)
        mouthOpen = smooth(mouthOpen, mouth.coerceIn(0f, 1f), .52f)
        smile = smooth(smile, smileAmount.coerceIn(0f, 1f), .35f)
        postInvalidateOnAnimation()
    }

    fun setAvatarBitmap(bitmap: Bitmap?) {
        remoteFrame = bitmap
        postInvalidateOnAnimation()
    }

    fun resetTracking() {
        yaw = smooth(yaw, 0f, .4f)
        pitch = smooth(pitch, 0f, .4f)
        roll = smooth(roll, 0f, .4f)
        faceX = smooth(faceX, .5f, .4f)
        faceY = smooth(faceY, .5f, .4f)
        leftEyeOpen = smooth(leftEyeOpen, 1f, .5f)
        rightEyeOpen = smooth(rightEyeOpen, 1f, .5f)
        mouthOpen = smooth(mouthOpen, 0f, .5f)
        smile = smooth(smile, 0f, .4f)
        postInvalidateOnAnimation()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        if (width <= 0 || height <= 0) return

        val bitmap = remoteFrame ?: portrait
        val scale = max(width.toFloat() / bitmap.width, height.toFloat() / bitmap.height)
        val drawW = bitmap.width * scale
        val drawH = bitmap.height * scale
        val left = (width - drawW) * .5f
        val top = (height - drawH) * .5f
        val dest = RectF(left, top, left + drawW, top + drawH)

        // Neural frames already contain the full generated motion. Draw them exactly as returned
        // by the GPU; applying the local 2D transform again would double the movement.
        if (remoteFrame != null) {
            canvas.drawBitmap(bitmap, null, dest, bitmapPaint)
            return
        }

        // Face anchor measured once on the bundled portrait.
        val anchorX = left + drawW * .505f
        val anchorY = top + drawH * .315f

        // Front camera tracking feels natural when horizontal translation is mirrored.
        val dx = (.5f - faceX) * width * .34f + (-yaw / 45f) * width * .045f
        val dy = (faceY - .5f) * height * .18f + (pitch / 35f) * height * .025f
        val yawScale = 1f - abs(yaw) / 45f * .045f
        val breathingScale = 1f + (-pitch / 35f) * .012f

        canvas.save()
        canvas.translate(dx, dy)
        canvas.rotate(-roll * .72f, anchorX, anchorY)
        canvas.scale(yawScale, breathingScale, anchorX, anchorY)
        canvas.drawBitmap(bitmap, null, dest, bitmapPaint)

        if (remoteFrame == null) {
            drawBlink(canvas, left, top, drawW, drawH, .426f, .252f, leftEyeOpen)
            drawBlink(canvas, left, top, drawW, drawH, .558f, .247f, rightEyeOpen)
            drawMouth(canvas, left, top, drawW, drawH)
        }
        canvas.restore()
    }

    private fun drawBlink(
        canvas: Canvas,
        left: Float,
        top: Float,
        drawW: Float,
        drawH: Float,
        nx: Float,
        ny: Float,
        eyeOpen: Float
    ) {
        val blink = (1f - eyeOpen).coerceIn(0f, 1f)
        if (blink < .28f) return

        val eyeW = drawW * .072f
        val eyeH = drawH * .026f
        val cx = left + drawW * nx
        val cy = top + drawH * ny
        val coverH = eyeH * (.25f + blink * .9f)
        val cover = RectF(cx - eyeW * .5f, cy - coverH * .48f, cx + eyeW * .5f, cy + coverH * .52f)

        skinPaint.alpha = (120 + blink * 120).toInt().coerceIn(0, 255)
        canvas.drawOval(cover, skinPaint)
        eyelidPaint.alpha = (130 + blink * 125).toInt().coerceIn(0, 255)
        canvas.drawArc(cover, 8f, 164f, false, eyelidPaint)
    }

    private fun drawMouth(canvas: Canvas, left: Float, top: Float, drawW: Float, drawH: Float) {
        val open = mouthOpen.coerceIn(0f, 1f)
        if (open < .055f) return

        val cx = left + drawW * .505f
        val cy = top + drawH * .360f
        val widthBoost = 1f + smile * .18f
        val mw = drawW * .067f * widthBoost
        val mh = drawH * (.003f + open * .026f)
        val inner = RectF(cx - mw * .5f, cy - mh * .37f, cx + mw * .5f, cy + mh * .63f)

        mouthPaint.alpha = (135 + open * 115).toInt().coerceIn(0, 255)
        canvas.drawOval(inner, mouthPaint)

        // Light lip edge keeps the mouth integrated with the portrait at small openings.
        val lip = RectF(inner.left - mw * .08f, inner.top - mh * .16f, inner.right + mw * .08f, inner.bottom + mh * .08f)
        lipPaint.alpha = (90 + open * 145).toInt().coerceIn(0, 255)
        canvas.drawArc(lip, 198f, 144f, false, lipPaint)
    }

    private fun smooth(current: Float, target: Float, factor: Float): Float =
        current + (target - current) * factor
}

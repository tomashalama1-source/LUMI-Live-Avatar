Open this /android folder in Android Studio.
Recommended: Android Studio Quail or newer, JDK 17, Android SDK 36.

If your checkout has no Gradle wrapper, Android Studio can create/use one:
  gradle wrapper --gradle-version 8.13

Then Sync Project with Gradle Files and Run on an Android 6.0+ phone.
The app bundles ML Kit face detection, so local face tracking starts immediately.
